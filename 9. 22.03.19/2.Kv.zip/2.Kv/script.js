// Счетчики
// 5 квадратов внутри каждого из которых
// изначально вписана
// цифра 0, при клике на любой квадрат
// цифра в нем увеличивается на один
//
// * сделать чтоб внутри квадратов были кнопки +/-

const btnPlus = document.querySelectorAll('.btn_plus');
const btnMinus = document.querySelectorAll('.btn_minus');

btnPlus.forEach(function (item) {

    const parent = item.parentNode;
    parent.dataset.step = '0';

    console.dir(parent);

    item.addEventListener('click', function () {
        let step = +this.parentNode.dataset.step + 1;

        this.parentNode.dataset.step = step.toString();
        this.parentNode.children[1].innerText = ''+ step +'';


        // const cop = this.parentNode.children;
        // for(let i = 0; i < cop.length; i++){
        //     if(cop[i].classList.contains('count')){
        //         cop[i].innerText = ''+ step +'';
        //     }
        // }
    })

});

btnMinus.forEach(function (item) {

    item.addEventListener('click', function () {
        let step = +this.parentNode.dataset.step - 1;

        this.parentNode.dataset.step = step.toString();
        this.parentNode.children[1].innerText = ''+ step +'';


        // const cop = this.parentNode.children;
        // for(let i = 0; i < cop.length; i++){
        //     if(cop[i].classList.contains('count')){
        //         cop[i].innerText = ''+ step +'';
        //     }
        // }
    })
});
