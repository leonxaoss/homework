// Счетчики
// 5 квадратов внутри каждого из которых
// изначально вписана
// цифра 0, при клике на любой квадрат
// цифра в нем увеличивается на один
//
// * сделать чтоб внутри квадратов были кнопки +/-


const block = document.querySelectorAll('.block');

function Counter(item){
    let counter = 0;

    this.countPlus = function () {
        counter++;
        item.children[1].innerText = ''+ counter +'';
    };
    this.countMinus = function () {
        counter--;
        item.children[1].innerText = ''+ counter +'';
    };
}

block.forEach(function (item) {
    const count = new Counter(item);
    item.addEventListener('click', function (event) {
        let target = event.target;
        while (target !== this) {
            if (target.classList.contains('btn_plus')) {
                count.countPlus();
                return;
            } else if(target.classList.contains('btn_minus')){
                count.countMinus();
                return;
            } else{
                target = target.parentNode;
            }
        }
    })
});
